package com.sakura.project_shop.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.sakura.project_shop.R;

public class MyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my);

        Button messagebutton = findViewById(R.id.a5);
        Button feedbackbutton = findViewById(R.id.a8);
        Button addresssbutton = findViewById(R.id.a6);
        Button CustomerServicebutton = findViewById(R.id.a7);
        messagebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MyActivity.this, UserMessageActivity.class);
                startActivity(intent);
            }
        });
        feedbackbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MyActivity.this, FeedbackActivity.class);
                startActivity(intent);
            }
        });
        addresssbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MyActivity.this, AddressActivity.class);
                startActivity(intent);
            }
        });
        CustomerServicebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MyActivity.this, "Pls call 400-111-111", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
