package com.sakura.project_shop.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.sakura.project_shop.R;

public class Goods_List extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goods__list);
    }
}
