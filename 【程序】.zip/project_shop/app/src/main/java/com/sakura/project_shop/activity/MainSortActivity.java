package com.sakura.project_shop.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.sakura.project_shop.R;

public class MainSortActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_sort);
        Button computerbutton = findViewById(R.id.computer);
        Button backbutton = findViewById(R.id.back);
        Button searchbutton = findViewById(R.id.search);
        computerbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainSortActivity.this, SortActivity.class);
                startActivity(intent);
            }
        });
        backbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainSortActivity.this, ChoiceActivity.class);
                startActivity(intent);
            }
        });
        searchbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainSortActivity.this, Goods_List.class);
                startActivity(intent);
            }
        });
    }
}
